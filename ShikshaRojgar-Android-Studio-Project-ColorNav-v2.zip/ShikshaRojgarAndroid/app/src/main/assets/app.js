/* Shiksha Rojgar • Blogger live content
   Default source: https://www.shiksharojgar.com
   The app reads the public Blogger feed; no separate database is required.
*/
const BLOGGER_URL = 'https://www.shiksharojgar.com';
const POSTS_LIMIT = 30;
const AUTO_REFRESH_MS = 10 * 60 * 1000;

const content={home:['Shiksha Rojgar','शिक्षा, रोजगार और परीक्षा से जुड़ी जानकारी एक ही जगह।'],teacher:['शिक्षक','भर्ती, नियुक्ति, प्रशिक्षण और शिक्षक संबंधी अपडेट।'],student:['विद्यार्थी','पढ़ाई, करियर, छात्रवृत्ति और मार्गदर्शन।'],jobs:['वैकेंसी / Jobs','सरकारी और निजी रोजगार की नई जानकारी।'],result:['रिजल्ट','विभिन्न परीक्षाओं के परिणाम और रिजल्ट लिंक।'],admit:['एडमिट कार्ड','परीक्षाओं के प्रवेश पत्र और डाउनलोड जानकारी।'],exam:['एग्जाम','परीक्षा तिथि, सिलेबस, मॉडल पेपर और तैयारी।'],study:['सिलेबस / अध्ययन सामग्री','कक्षा एवं प्रतियोगी परीक्षाओं की अध्ययन सामग्री।'],notice:['नोटिस / अपडेट','महत्वपूर्ण सूचनाएँ और आधिकारिक अपडेट।'],career:['करियर गाइड','करियर, कोर्स और रोजगार मार्गदर्शन।'],tools:['उपयोगी टूल्स','विद्यार्थियों और नौकरी चाहने वालों के लिए उपयोगी टूल्स।'],more:['More','ऐप की जानकारी और अपडेट विकल्प।'],all:['सभी अपडेट','Shiksha Rojgar की नवीनतम पोस्ट।']};

let allPosts=[];
const $=s=>document.querySelector(s);
const escapeHtml=s=>String(s??'').replace(/[&<>"']/g,m=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[m]));
const stripHtml=s=>{const d=document.createElement('div');d.innerHTML=s||'';d.querySelectorAll('script,style,noscript,template').forEach(n=>n.remove());return (d.textContent||d.innerText||'').replace(/\s+/g,' ').trim();};
const formatDate=s=>{if(!s)return '';try{return new Intl.DateTimeFormat('hi-IN',{day:'2-digit',month:'short',year:'numeric'}).format(new Date(s));}catch{return '';}};
const blogUrl=()=>BLOGGER_URL;
const feedUrl=()=>`${blogUrl()}/feeds/posts/default?alt=json&max-results=${POSTS_LIMIT}`;
const labelsOf=e=>(e.category||[]).map(c=>(c.term||'').toLowerCase());

function categoryFor(labels,title){
  const s=(labels.join(' ')+' '+title).toLowerCase();
  if(/admit|प्रवेश|hall ticket|हॉल टिकट/.test(s)) return 'एडमिट कार्ड';
  if(/result|रिजल्ट|परिणाम/.test(s)) return 'रिजल्ट';
  if(/vacancy|job|recruit|भर्ती|नौकरी|रोजगार/.test(s)) return 'वैकेंसी';
  if(/exam|परीक्षा|test|tet|ctet|neet|jee|timetable|time table|टाइम टेबल/.test(s)) return 'एग्जाम';
  if(/teacher|शिक्षक|अध्यापक|teacher/.test(s)) return 'शिक्षक';
  if(/student|विद्यार्थी|छात्र|scholarship|छात्रवृत्ति|school|स्कूल|admission|प्रवेश/.test(s)) return 'विद्यार्थी';
  return 'अपडेट';
}

function parsePosts(json){
  return (json.feed?.entry||[]).map(e=>{
    const title=stripHtml(e.title?.$t||'बिना शीर्षक');
    const raw=e.content?.$t||e.summary?.$t||'';
    const href=(e.link||[]).find(l=>l.rel==='alternate')?.href||'#';
    const published=e.published?.$t||e.updated?.$t||'';
    const labels=labelsOf(e);
    return {title,content:stripHtml(raw),html:raw,href,published,labels,category:categoryFor(labels,title),image:e.media$thumbnail?.url||''};
  });
}

function postCard(p){
  return `<article class="post-item" data-category="${escapeHtml(p.category)}" onclick="openPost(${allPosts.indexOf(p)})"><label>${escapeHtml(p.category)}</label><div class="post-main"><b>${escapeHtml(p.title)}</b><small>${escapeHtml(p.content.slice(0,150))}${p.content.length>150?'…':''}</small></div><time>${escapeHtml(formatDate(p.published))}</time></article>`;
}
function renderPosts(posts=allPosts){
  const box=$('#posts'); if(!box)return;
  if(!posts.length){box.innerHTML='<div class="empty">इस श्रेणी में अभी कोई पोस्ट नहीं मिली।</div>';return;}
  box.innerHTML=posts.map(postCard).join('');
}
function renderList(posts, target='#filtered'){
  const box=$(target); if(!box)return;
  box.innerHTML=posts.length?posts.map(postCard).join(''):'<p class="hint">इस श्रेणी की कोई पोस्ट अभी उपलब्ध नहीं है।</p>';
}

async function loadBloggerPosts(showLoading=true){
  if (window.Android && window.Android.refreshBlogger) { window.Android.refreshBlogger(); return true; }
  if(showLoading && !allPosts.length) $('#posts').innerHTML='<div class="loading">⏳ Shiksha Rojgar.com से ताजा पोस्ट लोड हो रही हैं…</div>';
  try{
    const res=await fetch(feedUrl(),{headers:{Accept:'application/json'},cache:'no-store'});
    if(!res.ok) throw new Error(`HTTP ${res.status}`);
    const json=await res.json();
    allPosts=parsePosts(json);
    renderPosts(); updateStats();
    const stamp=$('#lastUpdated'); if(stamp) stamp.textContent=`अपडेट: ${new Date().toLocaleTimeString('hi-IN',{hour:'2-digit',minute:'2-digit'})}`;
    return true;
  }catch(err){
    console.error(err);
    if(!allPosts.length) $('#posts').innerHTML='<div class="setup"><b>Shiksha Rojgar.com की पोस्ट अभी लोड नहीं हो पाईं</b><p>इंटरनेट कनेक्शन जाँचें और फिर कोशिश करें।</p><button onclick="loadBloggerPosts()">↻ फिर कोशिश करें</button></div>';
    return false;
  }
}

window.receiveBloggerJson=function(raw){
  try{ const json=typeof raw==='string'?JSON.parse(raw):raw; allPosts=parsePosts(json); renderPosts(); updateStats(); const stamp=$('#lastUpdated'); if(stamp) stamp.textContent=`अपडेट: ${new Date().toLocaleTimeString('hi-IN',{hour:'2-digit',minute:'2-digit'})}`; }
  catch(e){ console.error(e); if(!allPosts.length) $('#posts').innerHTML='<div class="setup"><b>डेटा पढ़ने में समस्या हुई</b><p>कृपया थोड़ी देर बाद फिर कोशिश करें।</p></div>'; }
};

function updateStats(){
  const count=k=>allPosts.filter(p=>p.category.toLowerCase().includes(k)).length;
  [['jobs','वैकेंसी'],['result','रिजल्ट'],['admit','एडमिट'],['exam','एग्जाम']].forEach(([k,label])=>{
    const el=document.querySelector(`.card.${k} small`); if(el) el.textContent=`${count(label)} पोस्ट • देखें`;
  });
}

function show(k){
  const x=content[k]||content.home;
  if(k==='more'){
    document.getElementById('content').innerHTML=`<div class="content-head"><h2>☰ More</h2><button class="refresh" onclick="loadBloggerPosts()">↻ Refresh</button></div><p>यह ऐप सीधे <b>ShikshaRojgar.com</b> के सार्वजनिक Blogger feed से नवीनतम सामग्री पढ़ता है। अलग database की जरूरत नहीं।</p><div class="info-box"><b>डेटा स्रोत</b><br>www.shiksharojgar.com<br><br><b>ऑटो अपडेट</b><br>ऐप लगभग हर 10 मिनट में नई पोस्ट जाँचता है।</div><p class="hint">पोस्ट का पूरा लेख ऐप में खोलने के लिए किसी पोस्ट पर टैप करें।</p>`;
  } else {
    document.getElementById('content').innerHTML=`<div class="content-head"><div><h2>${x[0]}</h2><p>${x[1]}</p></div><button class="refresh" onclick="loadBloggerPosts()">↻</button></div><div id="filtered"></div>`;
    if(['jobs','result','admit','exam','teacher','student','all'].includes(k)){
      const wanted={jobs:'वैकेंसी',result:'रिजल्ट',admit:'एडमिट',exam:'एग्जाम',teacher:'शिक्षक',student:'विद्यार्थी',all:''}[k];
      const posts=wanted?allPosts.filter(p=>p.category.includes(wanted)):allPosts;
      renderList(posts);
    }
  }
  window.scrollTo({top:document.getElementById('content').offsetTop-20,behavior:'smooth'});
  document.querySelectorAll('nav button').forEach(b=>b.classList.remove('active'));
  const navMap={home:0,jobs:1,exam:2,result:3,more:4}; if(navMap[k]!=null) document.querySelectorAll('nav button')[navMap[k]]?.classList.add('active');
}

function safeArticleHtml(html){
  const d=document.createElement('div'); d.innerHTML=html||'';
  d.querySelectorAll('script,style,iframe,object,embed,form').forEach(n=>n.remove());
  d.querySelectorAll('*').forEach(n=>{[...n.attributes].forEach(a=>{if(a.name.toLowerCase().startsWith('on'))n.removeAttribute(a.name);});});
  d.querySelectorAll('a').forEach(a=>{a.target='_blank';a.rel='noopener noreferrer';});
  d.querySelectorAll('img').forEach(img=>{img.loading='lazy';img.style.maxWidth='100%';img.style.height='auto';});
  return d.innerHTML;
}
function openPost(index){
  const p=allPosts[index]; if(!p)return;
  $('#articleTitle').textContent=p.title;
  $('#articleMeta').textContent=`${p.category} • ${formatDate(p.published)}`;
  $('#articleBody').innerHTML=safeArticleHtml(p.html)||`<p>${escapeHtml(p.content)}</p>`;
  $('#articleExternal').href=p.href;
  $('#articleModal').classList.add('show'); document.body.classList.add('modal-open');
}
function closePost(){ $('#articleModal').classList.remove('show'); document.body.classList.remove('modal-open'); }

function doSearch(){
  const q=$('#search').value.trim().toLowerCase();
  if(!q){renderPosts();return;}
  const found=allPosts.filter(p=>(p.title+' '+p.content+' '+p.labels.join(' ')).toLowerCase().includes(q));
  $('#posts').innerHTML=found.length?found.map(postCard).join(''):`<div class="empty">“${escapeHtml(q)}” के लिए कोई पोस्ट नहीं मिली।</div>`;
}

$('#search')?.addEventListener('keydown',e=>{if(e.key==='Enter')doSearch();});
$('#articleModal')?.addEventListener('click',e=>{if(e.target.id==='articleModal')closePost();});
if('serviceWorker' in navigator) navigator.serviceWorker.register('sw.js');
loadBloggerPosts();
setInterval(()=>loadBloggerPosts(false),AUTO_REFRESH_MS);
