# Shiksha Rojgar Android App

Play-Store-ready Android Studio project for **Shiksha Rojgar — शिक्षा • रोजगार • परीक्षा**.

## Included
- Custom colorful home screen
- Teacher, Student, Jobs, Result, Admit Card, Exam sections
- Live Blogger feed from `https://www.shiksharojgar.com`
- Native Android networking avoids WebView CORS issues
- Auto refresh every 10 minutes
- Android 16 / API 36 target for current Google Play new-app requirements

## Build in Android Studio
1. Install a current Android Studio that supports API 36.
2. Open this folder as a project.
3. Allow Gradle/Android SDK components to download.
4. Build > Generate Signed App Bundle / APK.
5. Choose **Android App Bundle (AAB)** for Google Play.
6. Create and securely keep your own upload/release keystore.

Google Play requires new apps to target Android 16 (API 36) or higher from 31 Aug 2026.

## Important
This workspace does not include a private release keystore. Do not publish with a shared/debug key. Keep your signing key backed up safely.

For Play Store, upload the signed `.aab`; Google Play generates device-specific APKs.
