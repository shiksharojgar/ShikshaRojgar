/* Shiksha Rojgar • live Blogger content + real page navigation */
const BLOGGER_URL='https://www.shiksharojgar.com';
const POSTS_LIMIT=30;
const AUTO_REFRESH_MS=10*60*1000;

const content={
 home:['Shiksha Rojgar','शिक्षा, रोजगार और परीक्षा से जुड़ी जानकारी एक ही जगह।'],
 teacher:['शिक्षक','भर्ती, नियुक्ति, प्रशिक्षण और शिक्षक संबंधी अपडेट।'],
 student:['विद्यार्थी','पढ़ाई, करियर, छात्रवृत्ति और मार्गदर्शन।'],
 jobs:['वैकेंसी / Jobs','सरकारी और निजी रोजगार की नई जानकारी।'],
 result:['रिजल्ट','विभिन्न परीक्षाओं के परिणाम और रिजल्ट लिंक।'],
 admit:['एडमिट कार्ड','परीक्षाओं के प्रवेश पत्र और डाउनलोड जानकारी।'],
 exam:['एग्जाम','परीक्षा तिथि, सिलेबस, मॉडल पेपर और तैयारी।'],
 study:['सिलेबस / अध्ययन सामग्री','कक्षा एवं प्रतियोगी परीक्षाओं की अध्ययन सामग्री।'],
 notice:['नोटिस / अपडेट','महत्वपूर्ण सूचनाएँ और आधिकारिक अपडेट।'],
 career:['करियर गाइड','करियर, कोर्स और रोजगार मार्गदर्शन।'],
 tools:['उपयोगी टूल्स','विद्यार्थियों और नौकरी चाहने वालों के लिए उपयोगी टूल्स।'],
 more:['More','ऐप की जानकारी और अपडेट विकल्प।'],
 all:['सभी अपडेट','Shiksha Rojgar की नवीनतम पोस्ट।']
};

let allPosts=[];
const $=s=>document.querySelector(s);
const escapeHtml=s=>String(s??'').replace(/[&<>"']/g,m=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[m]));
const stripHtml=s=>{const d=document.createElement('div');d.innerHTML=s||'';d.querySelectorAll('script,style,noscript,template').forEach(n=>n.remove());return(d.textContent||d.innerText||'').replace(/\s+/g,' ').trim();};
const formatDate=s=>{if(!s)return '';try{return new Intl.DateTimeFormat('hi-IN',{day:'2-digit',month:'short',year:'numeric'}).format(new Date(s));}catch{return '';}};
const feedUrl=()=>`${BLOGGER_URL}/feeds/posts/default?alt=json&max-results=${POSTS_LIMIT}`;
const labelsOf=e=>(e.category||[]).map(c=>(c.term||'').toLowerCase());

function categoryFor(labels,title){
 const s=(labels.join(' ')+' '+title).toLowerCase();
 if(/admit|प्रवेश|hall ticket|हॉल टिकट/.test(s))return'एडमिट कार्ड';
 if(/result|रिजल्ट|परिणाम/.test(s))return'रिजल्ट';
 if(/vacancy|job|recruit|भर्ती|नौकरी|रोजगार/.test(s))return'वैकेंसी';
 if(/exam|परीक्षा|test|tet|ctet|neet|jee|timetable|time table|टाइम टेबल/.test(s))return'एग्जाम';
 if(/teacher|शिक्षक|अध्यापक/.test(s))return'शिक्षक';
 if(/student|विद्यार्थी|छात्र|scholarship|छात्रवृत्ति|school|स्कूल|admission/.test(s))return'विद्यार्थी';
 return'अपडेट';
}

function parsePosts(json){
 return(json.feed?.entry||[]).map(e=>{
  const title=stripHtml(e.title?.$t||'बिना शीर्षक');
  const raw=e.content?.$t||e.summary?.$t||'';
  const href=(e.link||[]).find(l=>l.rel==='alternate')?.href||'#';
  const published=e.published?.$t||e.updated?.$t||'';
  const labels=labelsOf(e);
  return{title,content:stripHtml(raw),html:raw,href,published,labels,category:categoryFor(labels,title),image:e.media$thumbnail?.url||''};
 });
}

function postCard(p,index){
 return `<article class="post-item" data-category="${escapeHtml(p.category)}" onclick="openPost(${index})">
   <div class="post-badge ${badgeClass(p.category)}">${categoryIcon(p.category)}<span>${escapeHtml(p.category)}</span></div>
   <div class="post-main"><b>${escapeHtml(p.title)}</b><small>${escapeHtml(p.content.slice(0,150))}${p.content.length>150?'…':''}</small></div>
   <time>${escapeHtml(formatDate(p.published))}</time><span class="row-arrow">›</span>
 </article>`;
}
function badgeClass(c){return({'वैकेंसी':'jobs','रिजल्ट':'result','एडमिट कार्ड':'admit','एग्जाम':'exam','शिक्षक':'teacher','विद्यार्थी':'student'}[c]||'news');}
function categoryIcon(c){return({'वैकेंसी':'💼','रिजल्ट':'🏆','एडमिट कार्ड':'🎫','एग्जाम':'📝','शिक्षक':'👨‍🏫','विद्यार्थी':'🎓'}[c]||'📰');}
function renderPosts(posts=allPosts,target='#posts'){
 const box=$(target);if(!box)return;
 if(!posts.length){box.innerHTML='<div class="empty">इस श्रेणी में अभी कोई पोस्ट नहीं मिली।</div>';return;}
 box.innerHTML=posts.map((p,i)=>postCard(p,allPosts.indexOf(p))).join('');
}

async function loadBloggerPosts(showLoading=true){
 if(window.Android&&window.Android.refreshBlogger){window.Android.refreshBlogger();return true;}
 if(showLoading&&!allPosts.length)$('#posts').innerHTML='<div class="loading">⏳ Shiksha Rojgar.com से ताजा पोस्ट लोड हो रही हैं…</div>';
 try{
  const res=await fetch(feedUrl(),{headers:{Accept:'application/json'},cache:'no-store'});
  if(!res.ok)throw new Error(`HTTP ${res.status}`);
  allPosts=parsePosts(await res.json());
  renderPosts();updateStats();stampUpdated();
  refreshCurrentPage();
  return true;
 }catch(err){
  console.error(err);
  if(!allPosts.length)$('#posts').innerHTML='<div class="setup"><b>Shiksha Rojgar.com की पोस्ट अभी लोड नहीं हो पाईं</b><p>इंटरनेट कनेक्शन जाँचें और फिर कोशिश करें।</p><button onclick="loadBloggerPosts()">↻ फिर कोशिश करें</button></div>';
  return false;
 }
}
function stampUpdated(){const stamp=$('#lastUpdated');if(stamp)stamp.textContent=`अपडेट: ${new Date().toLocaleTimeString('hi-IN',{hour:'2-digit',minute:'2-digit'})} • लाइव`}
window.receiveBloggerJson=function(raw){try{allPosts=parsePosts(typeof raw==='string'?JSON.parse(raw):raw);renderPosts();updateStats();stampUpdated();refreshCurrentPage();}catch(e){console.error(e);}};

function updateStats(){
 const count=k=>allPosts.filter(p=>p.category.toLowerCase().includes(k)).length;
 [['jobs','वैकेंसी'],['result','रिजल्ट'],['admit','एडमिट'],['exam','एग्जाम']].forEach(([k,label])=>{const el=document.querySelector(`.card.${k} small`);if(el)el.textContent=`${count(label)} पोस्ट • देखें`;});
}

function setActiveNav(k){
 document.querySelectorAll('nav button').forEach(b=>b.classList.remove('active'));
 const navMap={home:'.nav-home',jobs:'.nav-jobs',exam:'.nav-exam',result:'.nav-result',more:'.nav-more'};
 if(navMap[k])$(navMap[k])?.classList.add('active');
}

function show(k,push=true){
 if(k==='home'){
  if(push)history.pushState({page:'home'},'',location.pathname+'#home');
  renderHome();setActiveNav('home');window.scrollTo({top:0,behavior:'smooth'});return;
 }
 if(k==='more'){
  if(push)history.pushState({page:'section',key:k},'',location.pathname+'#more');
  renderSection(k);setActiveNav('more');return;
 }
 if(push)history.pushState({page:'section',key:k},'',location.pathname+'#'+k);
 renderSection(k);setActiveNav(k);window.scrollTo({top:0,behavior:'smooth'});
}

function renderHome(){
 $('#appMain').innerHTML=`
  <section class="grid six">
   <button class="card teacher" onclick="show('teacher')"><span class="card-icon">👨‍🏫</span><b>शिक्षक</b><small>नियुक्ति, प्रशिक्षण, अपडेट</small><span class="open-arrow">→</span></button>
   <button class="card student" onclick="show('student')"><span class="card-icon">👨‍🎓</span><b>विद्यार्थी</b><small>पढ़ाई, करियर, मार्गदर्शन</small><span class="open-arrow">→</span></button>
   <button class="card jobs" onclick="show('jobs')"><span class="card-icon">💼</span><b>वैकेंसी</b><small>सरकारी/निजी नौकरी</small><span class="open-arrow">→</span></button>
   <button class="card result" onclick="show('result')"><span class="card-icon">🏆</span><b>रिजल्ट</b><small>परीक्षा परिणाम</small><span class="open-arrow">→</span></button>
   <button class="card admit" onclick="show('admit')"><span class="card-icon">🎫</span><b>एडमिट कार्ड</b><small>प्रवेश पत्र / हॉल टिकट</small><span class="open-arrow">→</span></button>
   <button class="card exam" onclick="show('exam')"><span class="card-icon">📝</span><b>एग्जाम</b><small>परीक्षा, मॉडल पेपर, तैयारी</small><span class="open-arrow">→</span></button>
  </section>
  <section class="quick">
   <button onclick="show('study')"><span class="quick-icon">🎓</span><b>सिलेबस / अध्ययन सामग्री</b></button>
   <button onclick="show('notice')"><span class="quick-icon">📢</span><b>नोटिस / अपडेट</b></button>
   <button onclick="show('career')"><span class="quick-icon">📚</span><b>करियर गाइड</b></button>
   <button onclick="show('tools')"><span class="quick-icon">⚙️</span><b>उपयोगी टूल्स</b></button>
  </section>
  <section class="updates"><div class="section-head"><div><h2>📣 ताजा अपडेट</h2><small id="lastUpdated">ShikshaRojgar.com से लाइव</small></div><button onclick="show('all')">सभी देखें →</button></div><div id="posts"><div class="loading">⏳ Shiksha Rojgar.com से ताजा पोस्ट लोड हो रही हैं…</div></div></section>
  <section class="banner"><strong>शिक्षा से सशक्त समाज</strong><span>रोजगार से समृद्ध भारत</span><em>पढ़ें • बढ़ें • सफल हों</em></section>
  <section class="home-info"><span>🇮🇳</span><div><b>Shiksha Rojgar.com से लाइव जानकारी</b><small>नई पोस्ट अपने आप ऐप में अपडेट होती रहेंगी।</small></div></section>
  <section class="exit-card"><div><b>↩ ऐप से बाहर निकलें</b><small>होम पेज पर Back दबाने से भी ऐप बंद किया जा सकता है।</small></div><button onclick="exitApp()">बाहर निकलें</button></section>`;
 renderPosts();updateStats();stampUpdated();
}

function renderSection(k){
 const x=content[k]||content.home;
 if(k==='more'){
  $('#appMain').innerHTML=`<section class="page-wrap"><button class="back-page" onclick="goBackPage()">‹ Back</button><div class="page-title more-title"><span>☰</span><div><h2>More</h2><p>ऐप की जानकारी, अपडेट और उपयोगी विकल्प</p></div></div><div class="info-box"><b>📡 लाइव डेटा स्रोत</b><br>www.shiksharojgar.com<br><br><b>🔄 ऑटो अपडेट</b><br>ऐप लगभग हर 10 मिनट में नई पोस्ट जाँचता है।<br><br><b>📱 नेविगेशन</b><br>हर श्रेणी और पोस्ट अलग पेज पर खुलती है। Back दबाकर पिछले पेज पर लौट सकते हैं।</div><div class="more-buttons"><button onclick="loadBloggerPosts()">↻ अभी अपडेट करें</button><button class="danger" onclick="exitApp()">↩ ऐप से बाहर निकलें</button></div></section>`;
  return;
 }
 const wanted={jobs:'वैकेंसी',result:'रिजल्ट',admit:'एडमिट',exam:'एग्जाम',teacher:'शिक्षक',student:'विद्यार्थी',all:''}[k]||'';
 const posts=wanted?allPosts.filter(p=>p.category.includes(wanted)):allPosts;
 $('#appMain').innerHTML=`<section class="page-wrap"><button class="back-page" onclick="goBackPage()">‹ Back</button><div class="page-title"><div class="page-icon ${badgeClass(x[0])}">${categoryIcon(x[0])}</div><div><h2>${escapeHtml(x[0])}</h2><p>${escapeHtml(x[1])}</p></div><button class="refresh" onclick="loadBloggerPosts()">↻</button></div><div class="category-note">📰 Shiksha Rojgar.com की इस श्रेणी की लाइव पोस्ट</div><div id="filtered"></div></section>`;
 renderPosts(posts,'#filtered');
}

function goBackPage(){
 if(history.length>1)history.back();else show('home',false);
}

function safeArticleHtml(html){
 const d=document.createElement('div');d.innerHTML=html||'';
 d.querySelectorAll('script,style,iframe,object,embed,form').forEach(n=>n.remove());
 d.querySelectorAll('*').forEach(n=>{[...n.attributes].forEach(a=>{if(a.name.toLowerCase().startsWith('on'))n.removeAttribute(a.name);});});
 d.querySelectorAll('a').forEach(a=>{a.target='_blank';a.rel='noopener noreferrer';});
 d.querySelectorAll('img').forEach(img=>{img.loading='lazy';img.style.maxWidth='100%';img.style.height='auto';});
 return d.innerHTML;
}

function openPost(index,push=true){
 const p=allPosts[index];if(!p)return;
 if(push)history.pushState({page:'post',index},'',location.pathname+'#post-'+index);
 $('#appMain').innerHTML=`<section class="page-wrap article-page"><button class="back-page" onclick="goBackPage()">‹ Back</button><div class="article-meta"><span class="post-badge ${badgeClass(p.category)}">${categoryIcon(p.category)} ${escapeHtml(p.category)}</span><time>${escapeHtml(formatDate(p.published))}</time></div><h1>${escapeHtml(p.title)}</h1><div class="article-body">${safeArticleHtml(p.html)||`<p>${escapeHtml(p.content)}</p>`}</div><a class="external" href="${escapeHtml(p.href)}" target="_blank" rel="noopener">🌐 मूल पोस्ट shiksharojgar.com पर खोलें</a></section>`;
 document.querySelectorAll('nav button').forEach(b=>b.classList.remove('active'));
 window.scrollTo({top:0,behavior:'smooth'});
}

function refreshCurrentPage(){
 const st=history.state;
 if(st?.page==='post'&&allPosts[st.index])openPost(st.index,false);
 else if(st?.page==='section'&&content[st.key])renderSection(st.key);
 else renderHome();
}

function doSearch(){
 const q=$('#search').value.trim().toLowerCase();
 if(!q){show('home');return;}
 const found=allPosts.filter(p=>(p.title+' '+p.content+' '+p.labels.join(' ')).toLowerCase().includes(q));
 history.pushState({page:'search',q},'',location.pathname+'#search');
 $('#appMain').innerHTML=`<section class="page-wrap"><button class="back-page" onclick="goBackPage()">‹ Back</button><div class="page-title"><div class="page-icon news">🔎</div><div><h2>खोज परिणाम</h2><p>“${escapeHtml(q)}” के लिए मिली पोस्ट</p></div></div><div id="filtered"></div></section>`;
 renderPosts(found,'#filtered');document.querySelectorAll('nav button').forEach(b=>b.classList.remove('active'));window.scrollTo({top:0,behavior:'smooth'});
}

function exitApp(){if(window.Android&&window.Android.exitApp){window.Android.exitApp();return;}window.close();}
window.appBack=function(){if(history.state&&history.state.page&&history.state.page!=='home'){history.back();return true;}return false;};
window.onpopstate=()=>{const st=history.state;if(st?.page==='post'&&allPosts[st.index])openPost(st.index,false);else if(st?.page==='section'&&content[st.key]){renderSection(st.key);setActiveNav(st.key);}else if(st?.page==='search'){doSearch();}else{renderHome();setActiveNav('home');}};
$('#search')?.addEventListener('keydown',e=>{if(e.key==='Enter')doSearch();});

if(!history.state)history.replaceState({page:'home'},'',location.pathname+'#home');
if('serviceWorker'in navigator)navigator.serviceWorker.register('sw.js');
loadBloggerPosts();
setInterval(()=>loadBloggerPosts(false),AUTO_REFRESH_MS);
