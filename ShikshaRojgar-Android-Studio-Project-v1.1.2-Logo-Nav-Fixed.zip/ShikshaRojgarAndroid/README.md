# Shiksha Rojgar Android App — v1.1.0

Updated Android Studio project for **Shiksha Rojgar — शिक्षा • रोजगार • परीक्षा**.

## इस अपडेट में
- दिए गए Shiksha Rojgar लोगो को ऐप के बाहर launcher icon और ऐप के अंदर header logo के रूप में लगाया गया है।
- Teacher, Student, Jobs, Result, Admit Card, Exam और अन्य sections अब अलग page view में खुलते हैं।
- हर category और हर live post के लिए स्पष्ट **‹ Back** विकल्प है। Android का Back button भी पिछले page पर लौटता है।
- Home page पर **ऐप से बाहर निकलें** विकल्प दिया गया है; Home पर Android Back से ऐप भी बंद होगा।
- Bottom navigation को floating, rounded और safe-area aware बनाया गया है ताकि फोन के नीचे वाले 3-button navigation area के पीछे दबे नहीं।
- News/posts के लिए रंगीन category badges और icons जोड़े गए हैं।
- Live Blogger feed और 10-minute auto refresh जारी है।
- Version 1.1.0 / versionCode 2.

## Build
1. Android Studio में `ShikshaRojgarAndroid` folder खोलें।
2. Gradle sync होने दें और API 36 SDK उपलब्ध रखें।
3. Build > Generate Signed App Bundle / APK चुनें।
4. Google Play के लिए signed **AAB** बनाएं।
5. अपनी private release/upload keystore को सुरक्षित रखें।

> इस project में private release keystore शामिल नहीं है।


### v1.1.1 update
- Added a dedicated VacancyBazaar.in live partner button with the supplied logo.
- Tapping it opens https://www.vacancybazaar.in/ inside the app WebView so the site's current postings remain live and Back returns to Shiksha Rojgar.
